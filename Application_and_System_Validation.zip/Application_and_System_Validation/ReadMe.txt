#Install Logging Module
Install-Module -Name Logging


Developed By : Vijay Saini ( techsckool@outlook.com )


	
.\Server_Validation.ps1 -server ServerA -tier_name web
.\Server_Validation.ps1 -server ServerB -tier_name app
.\Server_Validation.ps1 -server ServerC -tier_name database


.\Report_Consolidation.ps1


techsckool@outlook.com