
function Validate-SysInfo{

	$title = 'System Info'
	$status = 'INFORMATION'
	$output = '-'
	$comment = '-'
	
	$tmp = Get-ComputerInfo | select CsName,WindowsProductName,CsBootupState,OsLastBootUpTime,CsDomain
	$tmp = [ordered]@{
        CsName = $tmp.CsName
        WindowsProductName = $tmp.WindowsProductName
        CsBootupState = $tmp.CsBootupState
        OsLastBootUpTime  = $tmp.OsLastBootUpTime
        CsDomain = $tmp.CsDomain
    }
	
	$tmp_html = $tmp.GetEnumerator() | Select Name,Value | ConvertTo-Html -Fragment | out-string
	$tmp_html = $tmp_html -replace "<table", "<table id=subtable"
	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $tmp_html
					Comment = $comment
				}
	$summaryHash
}



function Validate-URL{
	
	$title = 'URL Validation'
	$status = ''
	$output = ''
	$comment = "Result is based upon http status code"
		
	try{
		$URIStatusCode = (Invoke-WebRequest -Uri $xml_ENVT_URL -UseBasicParsing -DisableKeepAlive).StatusCode
		if($URIStatusCode -eq 200 ){
			$status = 'SUCCESS'
			$output = "URL returned status code 200($xml_ENVT_URL)"
			Log-Message -level 'INFO' -msg "URL returned status code 200."
		} else{
			$status = 'FAILED'
			$output = "URL didnt return status code 200($xml_ENVT_URL)"
			Log-Message -level 'ERROR' -msg "URL didnt return status code 200."
			
		}
    } catch {
		$ErrorMessage = $_.Exception.Message
		
		$status = 'EXCEPTION'
		$output = "URL didnt return status code 200."
		Log-Message -level 'ERROR' -msg "Exception thrown while validating the URL. $ErrorMessage"
	}
	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash
}



function Validate-TopMemoryConsumingProcesses{

	$title = 'Top Memory Consuming Porcesses'
	$status = 'INFORMATION'
	$output = '-'
	$comment = "These are the processes found to be consuming maximum physical memory. "
	
	$tmp = Get-Process | Sort-Object -Descending WS | select -first 5 | select Name,Responding,WS,CPU | ConvertTo-Html -Fragment | out-string
	
	$tmp_html = $tmp -replace "<table", "<table id=subtable"
	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $tmp_html
					Comment = $comment
				}
	$summaryHash
}



function Validate-DiskHealth{

	$title = 'Disk Health Check1'
	$status = ''
	$output = '-'
	$comment = '-'
		
	$DiskSiZing = Get-Partition |   get-volume | select-Object DriveLetter,FileSystemLabel,HealthStatus,@{n="SizeRemaining";e={[math]::Round($_.SizeRemaining/1GB,2)}},@{n="Size";e={[math]::Round($_.Size/1GB,2)}} 
    $output = $DiskSiZing |  ConvertTo-HTML -Fragment | Out-String
	$output = $output -replace "<table", "<table id=subtable"
	
	$health_status = $DiskSiZing | Select-Object HealthStatus -ExpandProperty HealthStatus  -Unique  
    
	if( $health_status -eq 'Healthy'){
		$status = 'SUCCESS'
	} else{
		$status = 'FAILED'
	}
	
	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash
}



function Validate-SQLConnection{


	$title = 'SQL Connection Test'
	$status = ''
	$output = '-'
	$comment = 'This is TCP Connectivity check over SQL port 1433 to validate the connectivity with SQL server.'
	
	$conn = [bool] $( Test-NetConnection $xml_database_server -Port 1433 | select TCPTestSucceeded -ExpandProperty TCPTestSucceeded)
	
	if($conn){ 
		$status = 'SUCCESS'  
		$output = 'This server is able to communicate with database server'
	} else {  
		$status = 'FAILED'  
		$output = 'This server is unable to communicate with database server'
	}
		
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash		
}



function Validate-WebService{

	$validationTitle = 'Web Service Test'
	$status = 'SUCCESS'
	$comment = ''
	#$servies_to_validate_array = @("AarSvc_8bfdc","WSearch","nonsensesvc");
	$servies_to_validate_array = $xml_WEB_SERVICE.split(',');
	
	$output = '<table id=subtable><tr><th>Name</th><th>Status</th><th>Start Type</th><th>User</th></tr>'
	$servies_to_validate_array | ForEach-Object{
		$tmp_svc_obj = Get-Service -Name $_ -ErrorAction SilentlyContinue -ErrorVariable WindowsServiceExistsError
			
		if($WindowsServiceExistsError){
			$comment += "$_ service is not found on the $server`.`n"
			$status = 'FAILED'
		} else{
			$tmp=Get-WmiObject -Query "Select StartMode,StartName,State From Win32_Service Where Name=`'$_`'"
			$tmp_state=$tmp.State
			$tmp_mode=$tmp.StartMode
			$tmp_user=$tmp.StartName
			if($tmp_state -ne 'Running'){ $status = 'FAILED'	} 
			$output += "<tr><td><b>$_</b></td> <td>$tmp_state</td> <td>$tmp_mode</td> <td>$tmp_user</td></tr>"    
		}
	}
	$output += "</table>"
	
	
	$summaryHash = [PSCustomObject] @{
					Title = $validationTitle
					Status = $status
					Output = "$output"
					Comment = $tmp_msg
				}
	$summaryHash
		
}



function Validate-AppService{
	
	$validationTitle = 'App Service Test'
	$status = 'SUCCESS'
	$comment = 'Default message'
	$servies_to_validate_array = $xml_APP_SERVICE.split(',');
	
	$comment = ''
	$output = '<table id=subtable><tr><th>Name</th><th>Status</th><th>Start Type</th><th>User</th></tr>'
	$servies_to_validate_array | ForEach-Object{
			$tmp_svc_obj = Get-Service -Name $_ -ErrorAction SilentlyContinue -ErrorVariable WindowsServiceExistsError
			
			if($WindowsServiceExistsError){
				$comment += "$_ service is not found on the $server`.`n"
				$status = 'FAILED'
			} else{
				$tmp=Get-WmiObject -Query "Select StartMode,StartName,State From Win32_Service Where Name=`'$_`'"
				$tmp_state=$tmp.State
				$tmp_mode=$tmp.StartMode
				$tmp_user=$tmp.StartName
				if($tmp_state -ne 'Running'){ $status = 'FAILED'	} 
				$output += "<tr><td><b>$_</b></td> <td>$tmp_state</td> <td>$tmp_mode</td> <td>$tmp_user</td></tr>"    
			}
	}
	$output += "</table>"
	
	
	
	$summaryHash = [PSCustomObject] @{
					Title = $validationTitle
					Status = $status
					Output = "$output"
					Comment = $validateMessage
				}
	$summaryHash
		
}



function Validate-IIS{
	$title = 'IIS Check'
	$status = 'INFORMATION'
	$output = '-'
	$comment = '-'
	
	Import-Module webadministration
	
	$output = 'Website: <br>'
	$output += Get-Website | Select-Object Name, State | convertto-html -Fragment | Out-String
	$output += '<br> App Pools: <br>'
	$output += Get-IISAppPool | select name,State,ManagedPipelineMode, ManagedRuntimeVersion | ConvertTo-Html -Fragment | Out-String
	$output = $output -replace "<table", "<table id=subtable"


	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash
}



function Validate-SQLDatabase{
	$title = 'SQL Info'
	$status = 'INFORMATION'
	$output = '-'
	$comment = '-'
	
	$SQLServer = $xml_database_server
	$db = "master" 
	$select_query = "SELECT optname,value,major_version,minor_version,revision,install_failures FROM MSreplication_options"
	# The above query is just for reference. 

	$output = Invoke-Sqlcmd -ServerInstance $SQLServer -Database $db -Query $select_query | ConvertTo-Html -Fragment | Out-String
	$output = $output -replace "<table", "<table id=subtable"

	$summaryHash = [PSCustomObject] @{	
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash
}



function Validate-AppVersion{

	$title = 'Registry Validation'
	$status = '-'
	$output = '-'
	$comment = '-'
	
	$version = Get-ItemProperty -Path Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PowerShell\3\PowerShellEngine -Name PowerShellVersion | select PowerShellVersion -ExpandProperty PowerShellVersion
	
	if($version -like '5*'){
		$status = 'SUCCESS'
	} else {
		$status = 'FAILED'
	}
	
	$output = "Application Version = $version"
	$comment = 'Application version captured from registry'
	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash
}



function Validate-FolderPermissions{

	$title = 'Version Info'
	$status = 'INFORMATION'
	$output = '-'
	$comment = '-'
	
	$my_app_directory = "C:\inetpub\wwwroot"
	
	if(Test-Path $my_app_directory){
		$permission = (Get-Acl $my_app_directory).Access  | Where-Object { $_.FileSystemRights -like 'FullControl' }
		$permission | select IdentityReference,FileSystemRights,AccessControlType | ConvertTo-HTML -Fragment | Out-String
		$output = $permission -replace "<table", "<table id=subtable"
	}
	$comment = "These are the users who have FullControl on app dir ($my_app_directory)"
	
	$summaryHash = [PSCustomObject] @{
					Title = $title
					Status = $status
					Output = $output
					Comment = $comment
				}
	$summaryHash
}
