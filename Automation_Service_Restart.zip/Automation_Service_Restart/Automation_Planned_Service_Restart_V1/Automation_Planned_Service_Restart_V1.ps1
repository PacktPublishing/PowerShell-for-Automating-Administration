#  Script Name : Automation_Planned_Service_Restart_V1.ps1
#
#  Developed By: Vijay Saini
#  WebSite: https://www.techsckool.com/
#  Email: TechSckool@outlook.com
#
#  Scripting Language : PowerShell
#
#
#  Purpose : Stop and start services gracefully on multiple servers
#
#
#             

$BASE_DIR=(Resolve-Path .\).Path

$ddMMyyyy=(Get-Date).ToString('dd-MM-yyyy');
$LOG_FILE=$BASE_DIR + "\Daily_Service_Restart_$ddMMyyyy`.log"

Start-Transcript -Path "$LOG_FILE"

$config_file=$BASE_DIR + "\servers.ini"
$arr_servers=Get-Content $config_file


$services = "pla","Spooler","WpnService"


write-output "$(get-date) :INFO Staring the script Execution "

Invoke-Command -ComputerName $arr_servers -ScriptBlock {
    $sleeptime =3;
	
    write-output "$(get-date) :INFO Fetching the initial status of services "
    Get-Service -Name $Using:services  | select name, status, PSComputerName 

    write-output "$(get-date) :INFO Stopping services "
	Stop-Service -Name $Using:services 
       
    sleep($sleeptime) 
	
    write-output "$(get-date) :INFO Checking the status to see if the services are stopped"
    Get-Service -Name $Using:services  | select name, status, PSComputerName
     
	 
    write-output "$(get-date) :INFO Starting the services"
    Start-Service -Name $Using:services 
 
    sleep($sleeptime) 
    write-output "$(get-date) :INFO Final Status"
    Get-Service -Name $Using:services  | select name, status, PSComputerName
}

Stop-Transcript
