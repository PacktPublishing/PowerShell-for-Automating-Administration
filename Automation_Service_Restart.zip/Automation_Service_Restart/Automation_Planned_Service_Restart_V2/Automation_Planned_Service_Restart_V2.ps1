#  Script Name : Automation_Planned_Service_Restart_V1.ps1
#
#  Developed By: Vijay Saini
#  WebSite: https://www.techsckool.com/
#  Email: TechSckool@outlook.com
#
#  Scripting Language : PowerShell
#
#  Purpose : Stop and start services gracefully on multiple servers
#             

#Setting up variables
$BASE_DIR=(Resolve-Path .\).Path

$ddMMyyyy=(Get-Date).ToString('dd-MM-yyyy');
$LOG_FILE=$BASE_DIR + "\Daily_Service_Restart_$ddMMyyyy`.log"

Start-Transcript -Path "$LOG_FILE"

$xml_config=$BASE_DIR + "\configuration_file.xml"
[xml]$xml_content=Get-Content $xml_config



write-output "$(get-date) :INFO Staring the script Execution "  

foreach ( $entity in $xml_content.SERVICE_RESTART.SERVER_SERVICE_COMBINATION ){
	
	
	$servers = ($entity.SERVERS).split(',')
	$services = ($entity.SERVICES).split(',')
	
	Invoke-Command -ComputerName $servers -ScriptBlock {
		$sleeptime =30;
		
		write-output "$(get-date) :INFO Fetching the initial status of services "
		Get-Service -Name $Using:services  | select name, status, PSComputerName 

		write-output "$(get-date) :INFO Stopping services "
		Stop-Service -Name $Using:services 
		   
		sleep($sleeptime) 
		write-output "$(get-date) :INFO Checking the status to see if the services are stopped"
		Get-Service -Name $Using:services  | select name, status, PSComputerName
		 
		 sleep($sleeptime) 
		write-output "$(get-date) :INFO Starting the services"
		Start-Service -Name $Using:services 
	 
		 sleep($sleeptime) 
		write-output "$(get-date) :INFO Final Status"
		Get-Service -Name $Using:services  | select name, status, PSComputerName
	}

}
write-output "$(get-date) :INFO Script Execution Over" 

Stop-Transcript