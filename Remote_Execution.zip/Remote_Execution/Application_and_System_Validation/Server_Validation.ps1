<#
.Synopsis
   Execute the validation test cases on the server and prepare a summary in in html format
.DESCRIPTION
   Script Name : Server_Validation.ps1
   Developed By : Vijay Saini ( techsckool@outlook.com )
   Scripting Language : PowerShell
.EXAMPLE
   .\Server_Validation.ps1 -server AppServer2 -tier_name app
.EXAMPLE
   .\Server_Validation.ps1 -server SQL -tier_name database
.INPUTS
   Param1 : server - Name of server where you are executing the script, as you would like to see it in the report
   Param2: tier_name - Name of Tier as per your application architecture to which the server belongs. This tier must be available in the config file as well to map the task names
   Make sure the configuration file is reflecting correct data
.OUTPUTS
   An html report file with tabular summary of server validation results
#>


Param
    (
        [Parameter(Mandatory=$true)]
        $server_name,
		
		[Parameter(Mandatory=$true)]	
        $tier_name
    )
	

$shared_directory = "\\terminal-server\Validation_Results\"
$ps_drive_name = 'output_psdrive'


if (Get-PSDrive $ps_drive_name -ErrorAction SilentlyContinue) {
	Write-Verbose 'The $ps_drive_name: drive is already in use.' -Verbose
} else {
	New-PSDrive -Name $ps_drive_name -PSProvider FileSystem -Root $shared_directory
}

$REPORTS_DIR = "$ps_drive_name`:\Reports"
$LOGS_DIR = "$ps_drive_name`:\logs"

$BASE_DIR=(Resolve-Path .\).Path

. "$BASE_DIR\library\common_functions.ps1"
. "$BASE_DIR\library\css_and_js_for_beauty.ps1"
. "$BASE_DIR\library\validation_functions.ps1"


$ddMMyyyy=(Get-Date).ToString('dd-MM-yyyy');
$logfile = "$LOGS_DIR\$server_name`-validation_script_log_$ddMMyyyy.log"


$xml_config=$BASE_DIR + "\healhtest_config.xml"
[xml]$xml_content=Get-Content $xml_config


Log-Message -level 'INFO' -msg 'Reading the configuration file'
Log-Message -level 'DEBUG' -msg $xml_content.InnerXml



Log-Message -level 'INFO' -msg 'Creating the global variables'

foreach ($val in $xml_content.VALIDATION.GlobalVariables.VAR){
	$varName = $val.NAME
	$varValue = $val.VALUE
	Set-Variable -Name $varName -Value $varValue -Scope Global
}

	
	
	
	
	Log-Message -level 'INFO' -msg "Reading the information for $tier_name tier from xml file."
	$node = $xml_content.SelectSingleNode("//*[@name='$($tier_name)']")
    $tier_name =  $node.NAME	
    $tier_tasks =  $node.TIER_TASKS
	


	Log-Message -level 'INFO' -msg "Invoking Validation on $server_name ( $tier_name ) "
	Log-Message -level 'INFO' -msg "Taks: $tier_tasks"
	

	$tmp = Trigger-ValidationJob -tier_tasks $tier_tasks
	





    $validation_summary = $tmp | ConvertTo-Html -Fragment
	$validation_summary = $validation_summary -replace	'&lt;' , '<'
	$validation_summary = $validation_summary -replace	'&gt;' , '>'
		



	$report_dir = "$REPORTS_DIR\$($xml_cust_name)_$($xml_env_name)"
	
	if(!( Test-Path $report_dir) ){
		#Remove-Item $report_dir -force
		New-Item -type Directory -path $report_dir
	}
	
	$validation_summary | out-file "$report_dir\$($server_name)_$($tier_name).html"
	
Remove-PSDrive -name $ps_drive_name