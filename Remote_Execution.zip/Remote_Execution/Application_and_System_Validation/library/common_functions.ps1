<#
function Log-Message($level, $msg){
    Write-Log -Level $level -Message "$msg"
    Start-Sleep -Milliseconds 1
}
#>

function Log-Message($level, $msg){
	Write-Output "$(get-date) :  $level :  $msg" | Out-Host
	Write-Output "$(get-date) :  $level :  $msg" | Out-File $logfile -Append
}


function Trigger-ValidationJob {
    
    Param
    (
        $tier_tasks
    )


	$tier_tasks = $tier_tasks.Split(',') 

	Log-Message -level 'INFO' -msg "Validation Job Started"
	Log-Message -level 'INFO' -msg "tier_tasks : $tier_tasks "


	$server_validation_result = New-Object -TypeName System.Collections.ArrayList
	

	$tier_tasks | ForEach-Object{
		
        $task_name = $_
        $call_func = "Validate-"+$task_name
		
		Log-Message -level 'INFO' -msg "Calling function $call_func"
		
		try{
			
			$tmp = & $call_func
			[void]$server_validation_result.Add($tmp)
	  
		} catch{
			
			$ErrorMessage = $_.Exception.Message
			Log-Message -level 'ERROR' -msg "Error Calling function with args $call_func :"
			Log-Message -level 'ERROR' -msg "ErrorMessage: $ErrorMessage"
			
			$tmp = [PSCustomObject] @{
					Title = "$call_func"
					Status = 'EXCEPTION'
					Output = "$ErrorMessage"
					Comment = 'Please check the logs and fix the root cause.'
				}
			[void]$server_validation_result.Add($tmp)
			
		}
        
		Log-Message -level 'INFO' -msg "---------------------"
        
	}

	Log-Message -level 'INFO' -msg "Validation Job Ended"
	$server_validation_result 
}