
Param
    (
        [Parameter(Mandatory=$true)]
        $server_name,
		
		[Parameter(Mandatory=$true)]	
        $tier_name
    )
	

Get-Location
Write-Verbose ostname -Verbose
#This script is to pull the code from remote shared path and execute it locally on the server

#$cred = Get-Credential


$LOCAL_WORKING_DIRECTORY = 'D:\'


$REMOTE_SHARED_REPOSITORY_UNC_PATH = "\\Terminal-server\REMOTE_SHARED_REPOSITORY"
$PS_DRIVE_NAME = 'shared_repos'


if (Get-PSDrive $PS_DRIVE_NAME -ErrorAction SilentlyContinue) {
	Write-Verbose 'The $ps_drive_name: drive is already in use.' -Verbose
} else {
    Write-Verbose 'Creating the ps drive' -Verbose
	New-PSDrive -Name "$PS_DRIVE_NAME" -PSProvider FileSystem -Root "$REMOTE_SHARED_REPOSITORY_UNC_PATH"  -Credential $Using:cred 
}


$CODE_TO_EXECUTE_PSDRIVE = "$PS_DRIVE_NAME`:\Application_and_System_Validation"


$local_code_directory = "$LOCAL_WORKING_DIRECTORY\local_code_copy"

Write-Verbose "Removing the older copy of the code" -Verbose
Remove-Item -Path "$local_code_directory" -Recurse -Force -ErrorAction SilentlyContinue


Write-Verbose "Fetching the code to execute"  -Verbose
Copy-Item -Path $CODE_TO_EXECUTE_PSDRIVE -Destination $local_code_directory -Recurse


Set-Location -Path $local_code_directory
Write-Verbose "Invoking script locally"  -Verbose
Invoke-Expression "$local_code_directory\Server_Validation.ps1 -server_name $server_name -tier_name $tier_name"

