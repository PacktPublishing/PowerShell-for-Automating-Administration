$cred = Get-Credential testingpurpose@vijaysainiprofessionalgmail.onmicrosoft.com


Invoke-Command -Computername Applicationserv -FilePath "C:\Users\testingpurpose\Desktop\Centralized_Control\Pull_Script_and_Run.ps1" -ArgumentList "ApplicationServer","app"  -Credential $cred



Invoke-Command -Computername appserver01 -FilePath "C:\Users\testingpurpose\Desktop\Centralized_Control\Pull_Script_and_Run.ps1" -ArgumentList "appserver01","app"  -Credential $cred



Invoke-Command -Computername SQLServer -FilePath "C:\Users\testingpurpose\Desktop\Centralized_Control\Pull_Script_and_Run.ps1" -ArgumentList "SQLServer","database"  -Credential $cred


