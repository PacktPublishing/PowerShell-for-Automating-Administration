<#
.Synopsis
   Consolidate server level html reports into a consolidated html report
.DESCRIPTION
   Script Name : Report_Consolidation.ps1
   Developed By : Vijay Saini ( techsckool@outlook.com )
   Scripting Language : PowerShell
   External Module : logging
.INPUTS
   Make sure the configuration file is reflecting correct data
.OUTPUTS
   A Consolidated HTML report is generated at the Reports directory
#>



if (Get-Module -ListAvailable -Name logging) {
   Write-Host 'Logging Module in installed already'
} else {
    Write-Host 'Logging Module in not installed. Installing the module now'
	Install-Module logging -Confirm:$False -Force
	
	Get-Module -ListAvailable -Name logging
}


$config_filename = "healhtest_config.xml"
 
#Setting variables
$BASE_DIR=(Resolve-Path .\).Path
$REPORTS_DIR = $BASE_DIR + "\Reports"
#$REPORTS_DIR = "\\webserver\Shared_Reports"

. "$BASE_DIR\library\common_functions.ps1"
. "$BASE_DIR\library\css_and_js_for_beauty.ps1"
. "$BASE_DIR\library\validation_functions.ps1"


Set-LoggingDefaultLevel -Level 'INFO'
Add-LoggingTarget -Name Console
Add-LoggingTarget -Name File -Configuration @{Path = $BASE_DIR+'\logs\system_validation_%{+%Y%m%d}.log'}


$xml_config=$BASE_DIR + "\$config_filename"
[xml]$xml_content=Get-Content $xml_config

Log-Message -level 'INFO' -msg 'Reading the configuration file'
Log-Message -level 'INFO' -msg "$xml_config"


#Creating Variables
foreach ($val in $xml_content.VALIDATION.GlobalVariables.VAR){
	$varName = $val.NAME
	$varValue = $val.VALUE
	Set-Variable -Name $varName -Value $varValue -Scope Global
}




#Prepairing HTML
Log-Message -level 'INFO' -msg "Exporting the data to create html report."

$individual_validation_reports_path = "$REPORTS_DIR\$($xml_cust_name)_$($xml_env_name)"
	
$nav_html_string = ""
$nav_html_string += "<div id='vertical-nav' class=`"vertical-menu`">"
$nav_html_string += "<a href='#' id='nav-item' class='link active' onclick=`"myFunction('summary')`" >Summary</a>"


$content_html_string = ""
$content_html_string += "<div id='content-area'>"



$summary_html = "<div id='content-area'> <div class='report_content' id=`"summary`">  <table id='summary_table'> <tr> <th>Server</th> <th>Tier</th> <th>Information</th> <th>Success</th> <th>Failed</th> <th>Exception</th> </tr>"


$individual_validation_reports = Get-ChildItem -Path $individual_validation_reports_path -Filter "*.html"

$individual_validation_reports | ForEach-Object {

    $file_name = $_.BaseName
    
    $server_name = $file_name.Split('_')[0]
    $tier_name = $file_name.Split('_')[1]
	
	$link_id = "$($server_name)_$($Tier_Name)"
	$link_display_name = "$($server_name)`( $($Tier_Name) )"

	$clickable_link_html = "<a href='#' id='nav-item' class='link' onclick=`"myFunction('$($link_id)')`" > $($link_display_name)</a>"
	$nav_html_string += $clickable_link_html
	
	$validation_summary = Get-Content $_.FullName

	
		# Prepairing Summary of validation Report
		$count_information = $validation_summary | Select-String '<td>INFORMATION</td>' | Measure-Object | Select-Object Count -ExpandProperty count
		$count_success = $validation_summary | Select-String '<td>SUCCESS</td>' | Measure-Object | Select-Object Count -ExpandProperty count
		$count_failed = $validation_summary | Select-String '<td>FAILED</td>' | Measure-Object | Select-Object Count -ExpandProperty count
		$count_exception = $validation_summary | Select-String '<td>EXCEPTION</td>' | Measure-Object | Select-Object Count -ExpandProperty count
		
		if( ($count_exception -gt 0) -or ($count_failed -gt 0)){
			$summary_html += "<tr style='background:#ff6666'> <td>$clickable_link_html</td> <td>$tier_name</td> <td>$count_information</td> <td>$count_success</td> <td>$count_failed</td> <td>$count_exception</td> </tr>"
		} else {
			$summary_html += "<tr> <td>$clickable_link_html</td> <td>$tier_name</td> <td>$count_information</td> <td>$count_success</td> <td>$count_failed</td> <td>$count_exception</td> </tr>"
		}
		#================
	
	$content_html_string +=  "
	<div class='report_content' id=`"$($link_id)`" style='display:none'> 
	<table style='width:100%'><tr> 
	 <td bgcolor='#D1C79F'> Information</td> 
     <td bgcolor='#23AF2A'> Test Successful</td> 
     <td bgcolor='#ff6666'> Test Failed</td> 
	 <td bgcolor='#ffa64d'> Exception Occurred</td> 
     </tr></table>
	 <br> <br>
	 $validation_summary 
	 </div>" 
	
}
$summary_html +=  "</table></div></div>"

$nav_html_string += "</div>"
$content_html_string += "</div>"


Log-Message -level 'INFO' -msg "Pushing the data into a html file"

$output_html_report = $REPORTS_DIR + "\Validation_Report_$($xml_cust_name)_$($xml_env_name).html"
Write-Output "$nav_html_string" | Out-File $output_html_report
Write-Output "$summary_html" | Out-File $output_html_report -Append
Write-Output "$content_html_string" | Out-File $output_html_report -Append
Write-Output "$html_style2" | Out-File $output_html_report -Append
Write-Output "$html_footer" | Out-File $output_html_report -Append



#Uncomment below statements to start deleting the intermediate reports
#Log-Message -level 'INFO' -msg "Deleting the temporary reports directory."
#Remove-Item $individual_validation_reports_path -Recurse

Log-Message -level 'INFO' -msg "Consolidation task is completed. End of script."

Invoke-Item $output_html_report


Wait-Logging
