
$html_style1 = @'

<script>
	// Add active class to the current button (highlight it)
	var header = document.getElementById("vertical-nav");
	var btns = header.getElementsByClassName("link");
	for (var i = 0; i < btns.length; i++) {
	  btns[i].addEventListener("click", function() {
	  var current = document.getElementsByClassName("active");
	  current[0].className = current[0].className.replace(" active", "");
	  this.className += " active";
	  });
	}
</script>

<script>
	function myFunction(div_name) {
		
	  var list = document.getElementsByClassName('report_content');
	  for (index = 0; index < list.length; ++index) {
		(list[index]).style.display = "none";
		}

	  var x = document.getElementById(div_name);
	  if (x.style.display === "none") {
		x.style.display = "block";
	  } 
	}
</script>
	
<style>
.vertical-menu {
  height: 100%;
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #444;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.vertical-menu a {
 padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
  font-family: Calibri, sans-serif;
}

.vertical-menu a:hover {
  background-color: #ccc;
}

.vertical-menu a.active {
  background-color: #04AA6D;
  color: white;
}

#content-area{
height: auto;
margin-top: 100px;
margin-right: 150px;
margin-left: 300px;
}

body{
background-color: #9195B1;
}
</style>

<style>
table {
    font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;
    border-collapse: collapse;
	background-color: #D4DCD8;
	width: 100%		
}

table td, table th {
    border: 1px solid #ddd;
    padding: 6px;
}

table tr:nth-child(even){background-color: #ECDBA7;}

table tr:hover {background-color: #ddd;}

table th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #454545;
    color: white;
}

#subtable th {
    padding-top: 5px;
    padding-bottom: 3px;
    text-align: left;
    background-color: #B69E9A;
    color: black;
}
#subtable tr:nth-child(even){background-color: #B7B3AD;}

</style> 

'@






$html_style2 = @'

<script>
	// Add active class to the current button (highlight it)
	var header = document.getElementById("vertical-nav");
	var btns = header.getElementsByClassName("link");
	for (var i = 0; i < btns.length; i++) {
	  btns[i].addEventListener("click", function() {
	  var current = document.getElementsByClassName("active");
	  current[0].className = current[0].className.replace(" active", "");
	  this.className += " active";
	  });
	}
</script>

<script>
	function myFunction(div_name) {
		
	  var list = document.getElementsByClassName('report_content');
	  for (index = 0; index < list.length; ++index) {
		(list[index]).style.display = "none";
		}

	  var x = document.getElementById(div_name);
	  if (x.style.display === "none") {
		x.style.display = "block";
	  } 
	}
</script>
	
<style>
.vertical-menu {
  height: 100%;
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #444;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.vertical-menu a {
 padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
  font-family: Calibri, sans-serif;
}

.vertical-menu a:hover {
  background-color: #ccc;
}

.vertical-menu a.active {
  background-color: #04AA6D;
  color: white;
}

#content-area{
height: auto;
margin-top: 100px;
margin-right: 150px;
margin-left: 300px;
}

body{
background-color: #9195B1;
}
</style>

<style>
table {
    font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;
    border-collapse: collapse;
	background-color: #D4DCD8;
	width: 100%
}

table td, table th {
    border: 1px solid #ddd;
    padding: 6px;
}

													

#summary_table tr:nth-child(even){background-color: #ECDBA7;}


table tr:hover {background-color: #ddd;}

table th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #454545;
    color: white;
}

#subtable th {
    padding-top: 5px;
    padding-bottom: 3px;
    text-align: left;
    background-color: #B69E9A;
    color: black;
}
#subtable tr:nth-child(even){background-color: #B7B3AD;}

</style> 



 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 

 <script type="text/javascript">
 $(document).ready(function() {
    $("td:nth-child(2)").each(function() {
        if ($(this).text() === "SUCCESS") {
            $(this).parent().addClass("success");
    	}
		
		if ($(this).text() === "FAILED") {
            $(this).parent().addClass("failed");
    	}
		
		if ($(this).text() === "EXCEPTION") {
            $(this).parent().addClass("exception");
    	}
		
		if ($(this).text() === "INFORMATION") {
            $(this).parent().addClass("information");
    	}
    });
});
</script>
  
  
  <style id="compiled-css" type="text/css">
.information { 
    background: #D1C79F;
}
.success { 
    background: #23AF2A;
}
.failed {
    background: #ff6666;
}
.exception {
    background: #ffa64d;
}
    /* EOS */
  </style>
'@



$html_footer = "</center> </body> </html>"
